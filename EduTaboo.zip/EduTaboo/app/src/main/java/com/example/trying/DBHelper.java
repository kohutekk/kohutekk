package com.example.trying;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    public static final String USER_TABLE = "USER_TABLE";
    public static final String COLUMN_USER_NAME = "USER_NAME";
    public static final String COLUMN_USER_SCORE = "USER_SCORE";

    public DBHelper(@Nullable Context context) {
        super(context, "username.db", null, 1);
    }

    //Called when used for the  first time a database is used
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = "CREATE TABLE " + USER_TABLE + " (" + COLUMN_USER_NAME + " TEXT, " + COLUMN_USER_SCORE + " INT)";
        db.execSQL(createTableStatement);
    }

    //Used when the database is changed
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean addOne(ScoreboardModel scoreboardModel){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_USER_NAME, scoreboardModel.getName());
        cv.put(COLUMN_USER_SCORE, scoreboardModel.getScore());

        long insert = db.insert(USER_TABLE, null, cv);
        if(insert == 1){
            return false;
        } else {
            return true;
        }
    }

    public List<ScoreboardModel> getEveryone(){
        List<ScoreboardModel> returnList = new ArrayList<>();

        //Get data from the DB
        String queryString = "SELECT * FROM " + USER_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);
        if(cursor.moveToFirst()){
            //Loop through the cursor
            do{
                String userName = cursor.getString(0);
                int userScore = cursor.getInt(1);
                ScoreboardModel newUser = new ScoreboardModel(userName, userScore);
                returnList.add(newUser);
            }while(cursor.moveToNext());
        }else{
            //Don't add anything to the list
        }

        //Closing
        cursor.close();
        db.close();
        return returnList;
    }
}
