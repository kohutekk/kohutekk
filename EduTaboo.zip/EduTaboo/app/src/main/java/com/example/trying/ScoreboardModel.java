package com.example.trying;

public class ScoreboardModel {

    private String name;
    private int score;

    //Constructors
    public ScoreboardModel(String name, int score) {
        this.name = name;
        this.score = score;
    }

    public ScoreboardModel() {
    }

    //toString is necessary for printing the contents of a class object
    @Override
    public String toString() {
        return "ScoreboardModel{" +
                "name='" + name + '\'' +
                ", score=" + score +
                '}';
    }

    //Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
}
