package com.example.trying;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

public class Scoreboard extends AppCompatActivity {

    Button mainmenuButton, updatebutton;
    EditText eUsername, eScore;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scoreboard);

        mainmenuButton = findViewById(R.id.mainmenuButton);
        updatebutton = findViewById(R.id.updateButton);
        eUsername = findViewById(R.id.usernameText);
        eScore = findViewById(R.id.scoreText);
        listView = findViewById(R.id.listView);

        //Button listeners for the add and view all buttons
        mainmenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainMenu();
            }
        });

        updatebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DBHelper dbHelper = new DBHelper(Scoreboard.this);

                //Adding to database
                ScoreboardModel scoreboardModel;
                try {
                    scoreboardModel = new ScoreboardModel(eUsername.getText().toString(), Integer.parseInt(eScore.getText().toString()));
                } catch (Exception e){
                    scoreboardModel = new ScoreboardModel("error", 0);
                }
                boolean success = dbHelper.addOne(scoreboardModel);

                //Updating list
                List<ScoreboardModel> everyone = dbHelper.getEveryone();
                ArrayAdapter scoreArrayAdapter = new ArrayAdapter<ScoreboardModel>(Scoreboard.this, android.R.layout.simple_list_item_1, everyone);
                listView.setAdapter(scoreArrayAdapter);
            }
        });
    }

    public void openMainMenu(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}