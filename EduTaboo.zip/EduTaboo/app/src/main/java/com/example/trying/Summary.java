package com.example.trying;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Summary extends AppCompatActivity {

    TextView textView;
    Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        textView = findViewById(R.id.textView);
        backButton = findViewById(R.id.backButton);

        //Button to get to the Main Menu
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainActivity();
            }
        });

        //Setting up reading the .txt in a scrolling paragraph form
        textView.setMovementMethod(new ScrollingMovementMethod());
        InputStream is = this.getResources().openRawResource(R.raw.description);
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuffer sbuffer = new StringBuffer();
        String data = "";

        //Conditions for the .txt file
        if(is != null){
            try {
                while ((data = reader.readLine()) != null){
                    sbuffer.append(data + "\n");
                }
                textView.setText(sbuffer);
                is.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }

    }

    public void openMainActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}